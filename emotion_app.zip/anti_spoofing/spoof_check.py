def is_real_face(frame):
    # Dummy anti-spoofing (always returns True)
    return True